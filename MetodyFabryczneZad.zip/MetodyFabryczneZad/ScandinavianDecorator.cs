public class ScandinavianDecorator : InteriorDecorator
{
    public override Desk MakeDesk(int priceLimit)
    {
        if (priceLimit < 1500)
        {
            return null;
        }
        else
        {
            return new ScandinavianDesk("Wood", 4, priceLimit);
        }
    }

    public override Wardrobe MakeWardrobe(int priceLimit)
    {
        if (priceLimit < 1000)
        {
            return null;
        }
        else if (priceLimit < 2000)
        {
            return new ScandinavianWardrobe(1920, "grey", false);
        }
        else
        {
            return new ScandinavianWardrobe(2500, "brown", true);
        }
    }
}