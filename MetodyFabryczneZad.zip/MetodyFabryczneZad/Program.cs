﻿using System;

class Program
{
    static void Main(string[] args)
    {
        InteriorDecorator classicDecorator = new ClassicDecorator();
        InteriorDecorator modernDecorator = new ModernDecorator();
        InteriorDecorator scandinavianDecorator = new ScandinavianDecorator();

        Desk classicDesk = classicDecorator.MakeDesk(500);
        Desk modernDesk = modernDecorator.MakeDesk(1000);
        Desk scandinavianDesk = scandinavianDecorator.MakeDesk(1500);

        Wardrobe classicWardrobe = classicDecorator.MakeWardrobe(700);
        Wardrobe modernWardrobe = modernDecorator.MakeWardrobe(1200);
        Wardrobe scandinavianWardrobe = scandinavianDecorator.MakeWardrobe(1700);

        Console.WriteLine("Produced desks:");
        Console.WriteLine($"Classic desk: {classicDesk?.GetType().Name ?? "null"}");
        Console.WriteLine($"Modern desk: {modernDesk?.GetType().Name ?? "null"}");
        Console.WriteLine($"Art deco desk: {scandinavianDesk?.GetType().Name ?? "null"}");

        Console.WriteLine("\nProduced wardrobes:");
        Console.WriteLine($"Classic wardrobe: {classicWardrobe?.GetType().Name ?? "null"}");
        Console.WriteLine($"Modern wardrobe: {modernWardrobe?.GetType().Name ?? "null"}");
        Console.WriteLine($"Art deco wardrobe: {scandinavianWardrobe?.GetType().Name ?? "null"}");
    }
}
