public class ModernDecorator : InteriorDecorator
{
    public override Desk MakeDesk(int priceLimit)
    {
        if (priceLimit < 1500)
        {
            return null;
        }
        else
        {
            return new ModernDesk("Metal", "Green");
        }
    }

    public override Wardrobe MakeWardrobe(int priceLimit)
    {
        if (priceLimit < 1000)
        {
            return null;
        }
        else if (priceLimit < 2000)
        {
            return new ModernWardrobe(1920, "brown", "Plastic");
        }
        else
        {
            return new ModernWardrobe(2500, "brown", "Metal and Wood");
        }
    }
}