public class ClassicDecorator : InteriorDecorator
{
    public override Desk MakeDesk(int priceLimit)
    {
        if (priceLimit < 500)
        {
            return null;
        }
        else if (priceLimit < 1000)
        {
            return new ClassicDesk("Wood", 100);
        }
        else
        {
            return new ClassicDesk("Wood", 200);
        }
    }

    public override Wardrobe MakeWardrobe(int priceLimit)
    {
        if (priceLimit < 1000)
        {
            return null;
        }
        else if (priceLimit < 2000)
        {
            return new ClassicWardrobe(1920, "brown", 6);
        }
        else
        {
            return new ClassicWardrobe(2500, "brown", 10);
        }
    }
}