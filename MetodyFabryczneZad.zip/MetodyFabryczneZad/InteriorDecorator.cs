public abstract class InteriorDecorator
{
    public abstract Desk MakeDesk(int priceLimit);
    public abstract Wardrobe MakeWardrobe(int priceLimit);
}