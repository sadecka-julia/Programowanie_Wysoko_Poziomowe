namespace DziedziczenieZad
{
    internal class FunnySmerf:SmerfyZEmocjami
    {
        public FunnySmerf(string smerfName, int smerfAge, int smerfAnnoying) : base(smerfName, smerfAge, smerfAnnoying)
        {
            this.ZnakRozpoznawczy = "Brak";
        }
    }
}