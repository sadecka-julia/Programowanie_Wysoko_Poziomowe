namespace DziedziczenieZad
{
    internal class SmerfyZEmocjami:Smerf
    {
        public int Annoying {get; set;}
        public SmerfyZEmocjami(string smerfName, int smerfAge, int smerfAnnoying) : base(smerfName, smerfAge)
        {
            Annoying = smerfAnnoying;
            this.ZnakRozpoznawczy = "Brak";
        }
    }
}