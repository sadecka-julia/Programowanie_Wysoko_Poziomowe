namespace DziedziczenieZad
{
    internal class SmerfyPracujace:Smerf
    {
        public int Importance {get; set;}
        public SmerfyPracujace(string smerfName, int smerfAge, int smerfImportance) : base(smerfName, smerfAge)
        {
            Importance = smerfImportance;
            this.ZnakRozpoznawczy = "Brak";
        }
    }
}