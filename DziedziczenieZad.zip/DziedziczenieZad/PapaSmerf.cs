namespace DziedziczenieZad
{
    internal class PapaSmerf:SmerfyPracujace
    {
        public PapaSmerf(string smerfName, int smerfAge, int smerfImportance) : base(smerfName, smerfAge, smerfImportance){
            this.ZnakRozpoznawczy = "Brak";
        }
        public void ZrobicEliksir(string problem)
        {
            base.Problem(problem);
            Console.WriteLine("Zrobiono eliksir na problem: {0}", problem);
        }
    }
}