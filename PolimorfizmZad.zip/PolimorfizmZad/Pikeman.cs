class Pikeman : Defender
{
    public override int Eat()
    {
        return 4;
    }

    public override string ReadyToFight()
    {
        return "Ready to defend!";
    }

    public override string ToString()
    {
        return "Pikeman";
    }
}