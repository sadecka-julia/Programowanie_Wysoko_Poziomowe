abstract class Inhabitant
{
    public abstract int Eat();
}