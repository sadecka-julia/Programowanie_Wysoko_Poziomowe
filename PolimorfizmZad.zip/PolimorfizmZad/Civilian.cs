class Civilian : Inhabitant
{
    public override int Eat()
    {
        return 2;
    }

    public override string ToString()
    {
        return "Civilian";
    }
}