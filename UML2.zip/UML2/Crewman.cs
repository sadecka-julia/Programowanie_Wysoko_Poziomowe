using System;
using System.Collections.Generic;
using System.Text;

namespace UML2
{
    class Crewman:Human
    {
        
    }
}