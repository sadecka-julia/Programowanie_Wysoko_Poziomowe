namespace PoleceniaIAdapteryZad
{
    interface IVisitTouristAttraction
    {
        void Visit();
    }
}